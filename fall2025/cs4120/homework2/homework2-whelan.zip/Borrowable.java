
public interface Borrowable {

    public double calculateBorrowCost(int days);
}
