# Homework 1 - Tyson Whelan

This project was generated and written in VSCode so it may be a bit different than one done in IntelliJ

### How to run

First, unzip/extract the contents of the zip file

```bash
# In directory of extracted zip file contents
cd src
javac Calculator.java
java Calculator
```

Repeat for other files
